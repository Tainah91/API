class Conta:
    pass