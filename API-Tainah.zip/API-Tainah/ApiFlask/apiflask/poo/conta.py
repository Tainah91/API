#A classe é um conjunto de objeto

class Conta:
    pass
    #O que uma classe tem?
    def __init__(self,id,descricao,valor):
        self.id = id
        self.descricao = descricao
        self.valor = valor

"""
Objetos
Construtor
Atributos
Funções (métodos)
    get
    set
    workers (trabalho)
"""