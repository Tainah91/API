class Pessoa:
    pass

    """
    Na classe Pessoa defina três atributos 
    NOME, IDADE, CPF
    Construtor

    """
    def __init__(self,id,nome,cpf):
        
        self.id = id
        self.nome = nome
        self.cpf = None